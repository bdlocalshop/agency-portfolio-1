<?php
// Diagnostic Test & Auto-Healer for Hostinger Deployment
header('Content-Type: text/html; charset=utf-8');

$actionMessage = null;
$actionError = null;

// Handle Actions
if (isset($_GET['action'])) {
    // 1. Server-side Zip Extraction
    if ($_GET['action'] === 'extract_zip' && !empty($_GET['file'])) {
        $zipFilename = basename($_GET['file']);
        $zipPath = __DIR__ . '/' . $zipFilename;
        if (file_exists($zipPath) && class_exists('ZipArchive')) {
            $zip = new ZipArchive();
            if ($zip->open($zipPath) === true) {
                $zip->extractTo(__DIR__);
                $zip->close();
                $actionMessage = "Successfully extracted {$zipFilename} directly into public_html!";
            } else {
                $actionError = "Failed to open zip archive: {$zipFilename}";
            }
        } else {
            $actionError = "Zip file {$zipFilename} not found or ZipArchive not available.";
        }
    }

    // 2. Fix nested vendor/vendor
    if ($_GET['action'] === 'fix_vendor_vendor' && is_dir(__DIR__ . '/vendor/vendor')) {
        $source = __DIR__ . '/vendor/vendor';
        $dest = __DIR__ . '/vendor';
        $items = scandir($source);
        $moved = 0;
        foreach ($items as $item) {
            if ($item === '.' || $item === '..') continue;
            @rename($source . '/' . $item, $dest . '/' . $item);
            $moved++;
        }
        @rmdir($source);
        $actionMessage = "Moved {$moved} packages from vendor/vendor into vendor/";
    }

    // 3. Fix deploy/ wrapper folder
    if ($_GET['action'] === 'fix_deploy_folder' && is_dir(__DIR__ . '/deploy')) {
        $source = __DIR__ . '/deploy';
        $dest = __DIR__;
        $items = scandir($source);
        $moved = 0;
        foreach ($items as $item) {
            if ($item === '.' || $item === '..') continue;
            @rename($source . '/' . $item, $dest . '/' . $item);
            $moved++;
        }
        @rmdir($source);
        $actionMessage = "Moved {$moved} items from deploy into public_html";
    }

    // 4. Fix hostinger_deploy/ wrapper folder
    if ($_GET['action'] === 'fix_hostinger_folder' && is_dir(__DIR__ . '/hostinger_deploy')) {
        $source = __DIR__ . '/hostinger_deploy';
        $dest = __DIR__;
        $items = scandir($source);
        $moved = 0;
        foreach ($items as $item) {
            if ($item === '.' || $item === '..') continue;
            @rename($source . '/' . $item, $dest . '/' . $item);
            $moved++;
        }
        @rmdir($source);
        $actionMessage = "Moved {$moved} items from hostinger_deploy into public_html";
    }
}

$phpVersion = PHP_VERSION;
$phpOk = version_compare(PHP_VERSION, '8.2.0', '>=');

// Check Extensions
$requiredExtensions = ['pdo', 'pdo_mysql', 'curl', 'mbstring', 'openssl', 'tokenizer', 'xml', 'ctype', 'json', 'fileinfo', 'zip'];
$extStatus = [];
foreach ($requiredExtensions as $ext) {
    $extStatus[$ext] = extension_loaded($ext);
}

// Check Writable Directories
$dirsToCheck = [
    'storage/logs' => __DIR__ . '/storage/logs',
    'storage/framework/views' => __DIR__ . '/storage/framework/views',
    'storage/framework/sessions' => __DIR__ . '/storage/framework/sessions',
    'storage/framework/cache/data' => __DIR__ . '/storage/framework/cache/data',
    'bootstrap/cache' => __DIR__ . '/bootstrap/cache',
];

$dirStatus = [];
foreach ($dirsToCheck as $label => $path) {
    if (!is_dir($path)) {
        @mkdir($path, 0775, true);
    }
    $testFile = $path . '/.perm_test_' . uniqid();
    $written = @file_put_contents($testFile, 'test');
    if ($written !== false) {
        @unlink($testFile);
        $dirStatus[$label] = true;
    } else {
        $dirStatus[$label] = false;
    }
}

// Check vendor files and structure
$targetDeprecationFile = __DIR__ . '/vendor/symfony/deprecation-contracts/function.php';
$deprecationFileExists = file_exists($targetDeprecationFile);

// Check if nested vendor or wrapper folders exist
$nestedVendorExists = is_dir(__DIR__ . '/vendor/vendor');
$deployFolderExists = is_dir(__DIR__ . '/deploy');
$hostingerDeployExists = is_dir(__DIR__ . '/hostinger_deploy');

// Check available Zip archives
$zipFiles = glob(__DIR__ . '/*.zip');

// List what is in vendor/
$vendorFolders = is_dir(__DIR__ . '/vendor') ? array_diff(scandir(__DIR__ . '/vendor'), ['.', '..']) : [];

// Check vendor/symfony/
$symfonyFolders = is_dir(__DIR__ . '/vendor/symfony') ? array_diff(scandir(__DIR__ . '/vendor/symfony'), ['.', '..']) : [];

// Try Autoloading
$autoloadOk = false;
$autoloadError = null;
if (file_exists(__DIR__ . '/vendor/autoload.php')) {
    try {
        require_once __DIR__ . '/vendor/autoload.php';
        $autoloadOk = true;
    } catch (\Throwable $e) {
        $autoloadError = $e->getMessage() . ' (' . basename($e->getFile()) . ':' . $e->getLine() . ')';
    }
} else {
    $autoloadError = 'vendor/autoload.php does not exist!';
}

// Try Booting Laravel App
$appOk = false;
$appError = null;
if ($autoloadOk && file_exists(__DIR__ . '/bootstrap/app.php')) {
    try {
        $app = require __DIR__ . '/bootstrap/app.php';
        $appOk = is_object($app);
    } catch (\Throwable $e) {
        $appError = $e->getMessage() . ' (' . basename($e->getFile()) . ':' . $e->getLine() . ')';
    }
}

// Parse .env for database
$envFile = __DIR__ . '/.env';
$envExists = file_exists($envFile);
$dbHost = 'localhost';
$dbPort = '3306';
$dbName = '';
$dbUser = '';
$dbPass = '';

if ($envExists) {
    $lines = file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        if (str_starts_with(trim($line), '#')) continue;
        if (str_contains($line, '=')) {
            [$key, $val] = explode('=', $line, 2);
            $key = trim($key);
            $val = trim($val, " \t\n\r\0\x0B\"'");
            if ($key === 'DB_HOST') $dbHost = $val;
            if ($key === 'DB_PORT') $dbPort = $val;
            if ($key === 'DB_DATABASE') $dbName = $val;
            if ($key === 'DB_USERNAME') $dbUser = $val;
            if ($key === 'DB_PASSWORD') $dbPass = $val;
        }
    }
}

// Test DB Connection
$dbError = null;
$dbOk = false;
$projectCount = null;

if (!empty($dbName) && !empty($dbUser)) {
    try {
        $dsn = "mysql:host={$dbHost};port={$dbPort};dbname={$dbName};charset=utf8mb4";
        $pdo = new PDO($dsn, $dbUser, $dbPass, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_TIMEOUT => 5,
        ]);
        $dbOk = true;

        try {
            $stmt = $pdo->query("SELECT count(*) as cnt FROM projects");
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $projectCount = $row['cnt'] ?? 0;
        } catch (\Throwable $t) {
            $projectCount = 'Table error: ' . $t->getMessage();
        }
    } catch (\Throwable $e) {
        $dbError = $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Server & Environment Diagnostics</title>
    <style>
        body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; background: #0f172a; color: #f8fafc; padding: 30px 20px; }
        .container { max-width: 840px; margin: 0 auto; background: #1e293b; border-radius: 12px; padding: 24px; border: 1px solid #334155; box-shadow: 0 10px 25px rgba(0,0,0,0.3); }
        h1 { margin-top: 0; color: #38bdf8; font-size: 24px; border-bottom: 1px solid #334155; padding-bottom: 12px; }
        .item { display: flex; justify-content: space-between; align-items: center; padding: 12px; border-bottom: 1px solid #334155; }
        .badge { padding: 4px 10px; border-radius: 6px; font-weight: 600; font-size: 13px; }
        .badge-ok { background: #166534; color: #bbf7d0; }
        .badge-fail { background: #991b1b; color: #fecaca; }
        .badge-warn { background: #854d0e; color: #fef08a; }
        .notice-box { padding: 14px; border-radius: 8px; margin: 16px 0; font-size: 14px; }
        .notice-success { background: #064e3b; color: #a7f3d0; border: 1px solid #059669; }
        .notice-error { background: #450a0a; color: #fecaca; border: 1px solid #dc2626; }
        .notice-warn { background: #451a03; color: #fde68a; border: 1px solid #d97706; }
        code { background: #334155; padding: 2px 6px; border-radius: 4px; color: #f1f5f9; font-size: 13px; }
        a.btn { display: inline-block; background: #0284c7; color: white; text-decoration: none; padding: 8px 16px; border-radius: 6px; font-weight: 600; font-size: 14px; }
        a.btn:hover { background: #0369a1; }
        a.btn-fix { background: #ea580c; }
        a.btn-fix:hover { background: #c2410c; }
        .folder-list { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 8px; }
        .folder-chip { background: #334155; padding: 3px 8px; border-radius: 4px; font-size: 12px; font-family: monospace; }
    </style>
</head>
<body>
<div class="container">
    <h1>Hostinger Server Diagnostic Report</h1>

    <?php if ($actionMessage): ?>
    <div class="notice-box notice-success">
        <strong>Success:</strong> <?= htmlspecialchars($actionMessage) ?>
    </div>
    <?php endif; ?>

    <?php if ($actionError): ?>
    <div class="notice-box notice-error">
        <strong>Error:</strong> <?= htmlspecialchars($actionError) ?>
    </div>
    <?php endif; ?>

    <!-- 1. VENDOR & AUTOLOAD INTEGRITY -->
    <h2 style="font-size: 18px; margin-top: 20px; color: #38bdf8;">1. Vendor & Autoload Integrity</h2>

    <div class="item">
        <div>
            <strong>Composer Autoloader</strong>
            <div style="font-size: 13px; color: #94a3b8;"><?= $autoloadOk ? 'Successfully loaded vendor/autoload.php' : 'Failed to load' ?></div>
        </div>
        <span class="badge <?= $autoloadOk ? 'badge-ok' : 'badge-fail' ?>"><?= $autoloadOk ? 'LOADED' : 'FAILED' ?></span>
    </div>
    <?php if ($autoloadError): ?>
    <div class="notice-box notice-error">
        <strong>Autoload Error:</strong> <?= htmlspecialchars($autoloadError) ?>
    </div>
    <?php endif; ?>

    <div class="item">
        <div>
            <strong>Target File: <code>symfony/deprecation-contracts/function.php</code></strong>
            <div style="font-size: 13px; color: #94a3b8;">Path: <?= htmlspecialchars($targetDeprecationFile) ?></div>
        </div>
        <span class="badge <?= $deprecationFileExists ? 'badge-ok' : 'badge-fail' ?>"><?= $deprecationFileExists ? 'FOUND' : 'MISSING' ?></span>
    </div>

    <!-- ZIP ARCHIVE EXTRACTION HELPER -->
    <?php if (!empty($zipFiles)): ?>
    <div class="notice-box notice-warn">
        <strong>Found <?= count($zipFiles) ?> Zip Archive(s) in <code>public_html/</code>:</strong><br>
        If Hostinger File Manager timed out or corrupted files during manual extraction, you can extract cleanly using PHP:
        <div style="margin-top: 10px; display: flex; gap: 10px; flex-wrap: wrap;">
            <?php foreach ($zipFiles as $zf): $zName = basename($zf); ?>
                <a href="?action=extract_zip&file=<?= urlencode($zName) ?>" class="btn btn-fix">
                    Extract <?= htmlspecialchars($zName) ?> via Server PHP
                </a>
            <?php endforeach; ?>
        </div>
    </div>
    <?php endif; ?>

    <?php if ($nestedVendorExists): ?>
    <div class="notice-box notice-warn">
        <strong>Notice: Nested <code>vendor/vendor</code> directory detected!</strong><br>
        When files were moved, the <code>vendor</code> folder was placed inside the existing <code>vendor</code> folder.<br>
        <div style="margin-top: 10px;">
            <a href="?action=fix_vendor_vendor" class="btn btn-fix">Click Here to Auto-Fix: Move vendor/vendor into vendor/</a>
        </div>
    </div>
    <?php endif; ?>

    <?php if ($deployFolderExists): ?>
    <div class="notice-box notice-warn">
        <strong>Notice: Subfolder <code>deploy/</code> detected!</strong><br>
        Your zip extracted into a subfolder named <code>deploy/</code> instead of the root <code>public_html</code>.<br>
        <div style="margin-top: 10px;">
            <a href="?action=fix_deploy_folder" class="btn btn-fix">Click Here to Auto-Fix: Move deploy/* to public_html/</a>
        </div>
    </div>
    <?php endif; ?>

    <?php if ($hostingerDeployExists): ?>
    <div class="notice-box notice-warn">
        <strong>Notice: Subfolder <code>hostinger_deploy/</code> detected!</strong><br>
        <div style="margin-top: 10px;">
            <a href="?action=fix_hostinger_folder" class="btn btn-fix">Click Here to Auto-Fix: Move hostinger_deploy/* to public_html/</a>
        </div>
    </div>
    <?php endif; ?>

    <div style="padding: 12px; border-bottom: 1px solid #334155;">
        <div style="font-size: 14px; font-weight: 600;">Packages found inside <code>vendor/</code> (<?= count($vendorFolders) ?> items):</div>
        <div class="folder-list">
            <?php foreach ($vendorFolders as $vf): ?>
                <span class="folder-chip <?= in_array($vf, ['symfony', 'laravel', 'filament', 'livewire']) ? 'style="color:#38bdf8;font-weight:bold;"' : '' ?>"><?= htmlspecialchars($vf) ?></span>
            <?php endforeach; ?>
        </div>
    </div>

    <?php if (!empty($symfonyFolders)): ?>
    <div style="padding: 12px; border-bottom: 1px solid #334155;">
        <div style="font-size: 14px; font-weight: 600;">Packages found inside <code>vendor/symfony/</code> (<?= count($symfonyFolders) ?> items):</div>
        <div class="folder-list">
            <?php foreach ($symfonyFolders as $sf): ?>
                <span class="folder-chip <?= $sf === 'deprecation-contracts' ? 'style="color:#4ade80;font-weight:bold;"' : '' ?>"><?= htmlspecialchars($sf) ?></span>
            <?php endforeach; ?>
        </div>
    </div>
    <?php else: ?>
    <div class="notice-box notice-error">
        <strong>Folder <code>vendor/symfony</code> is EMPTY or MISSING on server!</strong>
    </div>
    <?php endif; ?>

    <!-- 2. LARAVEL APPLICATION BOOT -->
    <h2 style="font-size: 18px; margin-top: 24px; color: #38bdf8;">2. Laravel 11 Application Boot</h2>
    <div class="item">
        <div>
            <strong>Laravel Application Instance</strong>
            <div style="font-size: 13px; color: #94a3b8;"><?= $appOk ? 'Bootstrapped from bootstrap/app.php' : 'Could not bootstrap' ?></div>
        </div>
        <span class="badge <?= $appOk ? 'badge-ok' : 'badge-fail' ?>"><?= $appOk ? 'BOOTED' : 'FAILED' ?></span>
    </div>
    <?php if ($appError): ?>
    <div class="notice-box notice-error">
        <strong>Laravel Boot Error:</strong> <?= htmlspecialchars($appError) ?>
    </div>
    <?php endif; ?>

    <!-- 3. DATABASE CHECK -->
    <h2 style="font-size: 18px; margin-top: 24px; color: #38bdf8;">3. Database Connection</h2>
    <div class="item">
        <div>
            <strong>MySQL Database</strong>
            <div style="font-size: 13px; color: #94a3b8;">Host: <code><?= htmlspecialchars($dbHost) ?></code> | DB: <code><?= htmlspecialchars($dbName) ?></code> | User: <code><?= htmlspecialchars($dbUser) ?></code></div>
        </div>
        <span class="badge <?= $dbOk ? 'badge-ok' : 'badge-fail' ?>"><?= $dbOk ? 'CONNECTED' : 'FAILED' ?></span>
    </div>
    <?php if ($dbOk): ?>
    <div class="item">
        <div>
            <strong>Projects Table Records</strong>
            <div style="font-size: 13px; color: #94a3b8;">Database import verification</div>
        </div>
        <span class="badge <?= is_numeric($projectCount) ? 'badge-ok' : 'badge-fail' ?>"><?= htmlspecialchars((string)$projectCount) ?> projects found</span>
    </div>
    <?php endif; ?>

    <!-- 4. PERMISSIONS & ENVIRONMENT -->
    <h2 style="font-size: 18px; margin-top: 24px; color: #38bdf8;">4. System & Directory Permissions</h2>
    <div class="item">
        <div>
            <strong>PHP Version (Required: &ge; 8.2)</strong>
            <div style="font-size: 13px; color: #94a3b8;">Current: <?= htmlspecialchars($phpVersion) ?></div>
        </div>
        <span class="badge <?= $phpOk ? 'badge-ok' : 'badge-fail' ?>"><?= $phpOk ? 'PASS ('.htmlspecialchars($phpVersion).')' : 'FAIL' ?></span>
    </div>

    <?php foreach ($dirStatus as $dir => $writable): ?>
    <div class="item" style="padding: 8px 12px;">
        <span>Path: <code><?= htmlspecialchars($dir) ?></code></span>
        <span class="badge <?= $writable ? 'badge-ok' : 'badge-fail' ?>"><?= $writable ? 'WRITABLE' : 'CHMOD 775 NEEDED' ?></span>
    </div>
    <?php endforeach; ?>

    <div style="margin-top: 30px; text-align: center;">
        <a href="/" class="btn" style="padding: 12px 24px; font-size: 16px;">&larr; Open Homepage (index.php)</a>
    </div>
</div>
</body>
</html>
